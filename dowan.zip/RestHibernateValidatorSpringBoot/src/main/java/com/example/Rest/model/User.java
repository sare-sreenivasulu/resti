package com.example.Rest.model;

import org.hibernate.validator.constraints.NotEmpty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;


public class User {

	  

	   @Column(name= "type" , nullable= false)
//	    type should not be null or empty
	    @NotEmpty
	    @Size(message= "type should be mandataory" )
	private String type;
	   @Column 
	   @NotEmpty
	   @Size(message="action should be mandatory")
	   private String  action;
	   
	   @Column 
	   @NotEmpty
	   @Size(message="path should be manadatory")
	   private String  path;
	   
	   @Column
	   @NotEmpty
	   @Size(message ="date should be mandatory")
	   private String  save_date;
	   
	   @Column 
	   @NotEmpty
	   @Size(message ="user should be mandatory")
	   private String  save_user;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getSave_date() {
		return save_date;
	}

	public void setSave_date(String save_date) {
		this.save_date = save_date;
	}

	public String getSave_user() {
		return save_user;
	}

	public void setSave_user(String save_user) {
		this.save_user = save_user;
	}

	@Override
	public String toString() {
		return "User [type=" + type + ", action=" + action + ", path=" + path + ", save_date=" + save_date
				+ ", save_user=" + save_user + "]";
	}

	public User(String type, String action, String path, String save_date, String save_user) {
		super();
		this.type = type;
		this.action = action;
		this.path = path;
		this.save_date = save_date;
		this.save_user = save_user;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	   
	   
}
