package com.example.Rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestHibernateValidatorSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestHibernateValidatorSpringBootApplication.class, args);
	}

}
